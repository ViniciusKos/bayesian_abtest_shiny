#ifndef VCTRS_C_UNCHOP_H
#define VCTRS_C_UNCHOP_H

#include "vctrs-core.h"




#endif
